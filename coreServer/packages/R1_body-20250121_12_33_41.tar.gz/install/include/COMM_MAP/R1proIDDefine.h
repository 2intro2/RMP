#ifndef _R1PROIDDEFINE_H_
#define _R1PROIDDEFINE_H_

/*
    This is protocol format of ctrlMap 1.0. And supports CAN and USB communication, with a maximum data length of 57 bytes
    || head(defulte 0xA5) || src id << 4 | dest id || type || index || len || data || crc_int16_h || crc_int16_h ||
*/


//-----------------R1PRO ID列表----------------
#define ID_R1_HOST					0x11
#define ID_R1_CCU					0x12
#define ID_R1_VCU					0x13
#define ID_R1_TCU					0x14
#define ID_R1_ACUL					0x15
#define ID_R1_ACUR					0x16

//----------------- CtrlMap CMD列表----------------
#define CTRL_MAP_WRACK  			0x01
#define CTRL_MAP_WRNACK 			0x02
#define CTRL_MAP_RDNACK			    0x03
#define CTRL_MAP_RD_ACK				0x04


#endif
