#include "R1proVcuCtrlMap.h"

int16_t gR1proVcuCtrlMap[VCU_CTRLMAP_LEN];
bool gR1proVcuMapUpdated[VCU_CTRLMAP_LEN] = {false};	
