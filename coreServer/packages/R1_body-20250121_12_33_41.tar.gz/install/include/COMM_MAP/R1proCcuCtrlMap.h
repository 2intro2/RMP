#ifndef _R1PROCCUCTRLMAP_H_
#define _R1PROCCUCTRLMAP_H_

#include <stdint.h>
#include <stdbool.h>

#define CCU_CTRLMAP_LEN						    256					

#define COMM_MAP_CCU_FW_VERSION						0x00	
// == IMU  (Standard 18 BYTE)
#define COMM_MAP_CCU_IMU_ROLL					0x10	
#define COMM_MAP_CCU_IMU_PITCH  				0x11	
#define COMM_MAP_CCU_IMU_YAW   					0x12
#define COMM_MAP_CCU_IMU_ACC_X					0x13	
#define COMM_MAP_CCU_IMU_ACC_Y					0x14	
#define COMM_MAP_CCU_IMU_ACC_Z					0x15	
#define COMM_MAP_CCU_IMU_GROY_X					0x16	
#define COMM_MAP_CCU_IMU_GROY_Y					0x17	
#define COMM_MAP_CCU_IMU_GROY_Z					0x18	
// == BATTERY  (Standard 6 BYTE)
#define COMM_MAP_CCU_BATTERY_VOL			    0x20	
#define COMM_MAP_CCU_BATTERY_CURRENT    	    0x21	
#define COMM_MAP_CCU_BATTERY_CAPITAL		    0x22	
// == REMOTE  (Standard 8 BYTE)
#define COMM_MAP_CCU_REMOTE_MODE		        0x30  // 0: free, 1: chassis_stop, 2: chassis_vector_ctrl, 3: chassis_transform_ctrl, 4: torso_ctrl, 5: auto 	
#define COMM_MAP_CCU_REMOTE_CHASSIS_VX		    0x31	 
#define COMM_MAP_CCU_REMOTE_CHASSIS_VY		    0x32	 
#define COMM_MAP_CCU_REMOTE_CHASSIS_W		    0x33	


#define COMM_MAP_CCU_REMOTE_TORSO_VX		    0x34
#define COMM_MAP_CCU_REMOTE_TORSO_VZ		    0x35
#define COMM_MAP_CCU_REMOTE_TORSO_VPITCH		0x36
#define COMM_MAP_CCU_REMOTE_TORSO_VYAW		    0x37

#define COMM_MAP_CCU_REMOTE_LIGHT_SWITCH	    0x38	 
#define COMM_MAP_CCU_REMOTE_RACORD_BAG	        0x39


// == REMOTE  (Standard 4 BYTE)
#define COMM_MAP_CCU_ERR_STATE_L	    0xF0
#define COMM_MAP_CCU_ERR_STATE_H	    0xF1

extern int16_t gR1proCcuCtrlMap[CCU_CTRLMAP_LEN];
extern bool gR1proCcuMapUpdated[CCU_CTRLMAP_LEN];

#endif 
