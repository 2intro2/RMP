#include "R1proAcuRCtrlMap.h"

int16_t gR1proAcuRCtrlMap[ACUR_CTRLMAP_LEN];
bool gR1proAcuRMapUpdated[ACUR_CTRLMAP_LEN] = {false};	
