#ifndef MAPMODULE_HPP
#define MAPMODULE_HPP

#include <string>
#include <unordered_map>

enum class CUType {
    CCU,
    VCU,
    TCU,
    ACU,
    UNKNOWN
};

class MapModule {
public:
    virtual uint8_t getControlID(const std::string& item) = 0;
    virtual uint8_t getFeedbackID(const std::string& item) = 0;
    virtual std::string getControlItemFromID(uint8_t id) = 0;
    virtual std::string getFeedbackItemFromID(uint8_t id) = 0;

    virtual ~MapModule() = default;
// private:

};


#endif //MAPMODULE_HPP