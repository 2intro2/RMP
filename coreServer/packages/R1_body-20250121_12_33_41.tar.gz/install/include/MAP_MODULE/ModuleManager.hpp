#ifndef MODULEMANAGER_HPP
#define MODULEMANAGER_HPP
#include "MAP_MODULE/MapModule.hpp"
#include "MAP_MODULE/VCU_MapModule.hpp"
#include <unordered_map>
#include <memory>
#include <string>
#include <iostream>

class ModuleManager {
public:
    ModuleManager();
    uint8_t getControlID(uint8_t destination_address, const std::string& control_item);

    uint8_t getFeedbackID(uint8_t source_address, const std::string& feedback_item);

    std::string getControlItemFromID(uint8_t destination_address, uint8_t control_id);

    std::string getFeedbackItemFromID(uint8_t source_address, uint8_t feedback_id);
private:
    CUType getCUTypeFromSourceAddress(uint8_t source_address);
    std::unordered_map<uint8_t, CUType> sourceAddressToCU;   
    std::unordered_map<CUType, std::shared_ptr<MapModule>> modules;
};



#endif //MODULEMANAGER_HPP