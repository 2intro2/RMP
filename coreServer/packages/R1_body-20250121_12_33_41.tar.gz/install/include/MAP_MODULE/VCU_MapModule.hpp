#ifndef VCU_MAPMODULE_HPP
#define VCU_MAPMODULE_HPP

#include "MAP_MODULE/MapModule.hpp"
#include <iostream>
class VCU_MapModule : public MapModule {
public:
    VCU_MapModule();
    uint8_t getControlID(const std::string& item) override;
    uint8_t getFeedbackID(const std::string& item) override;
    std::string getControlItemFromID(uint8_t id) override;
    std::string getFeedbackItemFromID(uint8_t id) override;
private:
    std::unordered_map<std::string, uint8_t> vcu_control_map = {
        {"Chassis", 0x20}
    };
    std::unordered_map<uint8_t, std::string> vcu_feedback_map = {
        {0x20, "Chassis"}
    };;
    std::unordered_map<uint8_t, std::string> vcu_module_map = {
        {0x20, "Chassis"}
    };
};

#endif //VCU_MAPMODULE_HPP