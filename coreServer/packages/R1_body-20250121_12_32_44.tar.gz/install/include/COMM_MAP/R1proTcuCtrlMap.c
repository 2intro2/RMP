#include "R1proTcuCtrlMap.h"

int16_t gR1proTcuCtrlMap[TCU_CTRLMAP_LEN];
bool gR1proTcuMapUpdated[TCU_CTRLMAP_LEN] = {false};	
