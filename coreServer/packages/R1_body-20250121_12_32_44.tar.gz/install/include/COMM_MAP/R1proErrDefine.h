#ifndef _R1PROERRDEFINE_H_
#define _R1PRORRDEFINE_H_

// == R1PRO ACU ERROR BIT LIST
#define R1PRO_ACU_ERR_BIT_MOTOR_ENABLE                  0
#define R1PRO_ACU_ERR_BIT_MOTOR_DISABLE                 1
#define R1PRO_ACU_ERR_BIT_DISCONNECT                    2
#define R1PRO_ACU_ERR_BIT_POS_JUMP                      3
#define R1PRO_ACU_ERR_BIT_CONTINUOUS_HIGH_CURRENT       4
#define R1PRO_ACU_ERR_BIT_TOR_JUMP                      5
#define R1PRO_ACU_ERR_BIT_RECEIVE_TIMEOUT               6
#define R1PRO_ACU_ERR_BIT_POS_EXCEED                    7
#define R1PRO_ACU_ERR_BIT_VEL_EXCEED                    8
#define R1PRO_ACU_ERR_BIT_TOR_EXCEED                    9
#define R1PRO_ACU_ERR_BIT_OVER_VOLTAGE                  10
#define R1PRO_ACU_ERR_BIT_UNDER_VOLTAGE                 11
#define R1PRO_ACU_ERR_BIT_OVER_CURRENT                  12
#define R1PRO_ACU_ERR_BIT_MOS_OVER_TEMP                 13
#define R1PRO_ACU_ERR_BIT_MOTOR_OVER_TEMP               14
#define R1PRO_ACU_ERR_BIT_COMMUNICATION_LOSS            15
#define R1PRO_ACU_ERR_BIT_OVERLOAD                      16
// == R1PRO CCU ERROR BIT LIST

// == R1PRO TCU ERROR BIT LIST
// == R1PRO ACUL ERROR BIT LIST
// == R1PRO ACUR ERROR BIT LIST





#endif
