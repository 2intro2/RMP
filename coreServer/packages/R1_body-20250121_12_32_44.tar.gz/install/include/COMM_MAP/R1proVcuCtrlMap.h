#ifndef _R1PROVCUCTRLMAP_H_
#define _R1PROVCUCTRLMAP_H_

#include <stdint.h>
#include <stdbool.h>

#define VCU_CTRLMAP_LEN						    256					

#define COMM_MAP_VCU_FW_VERSION						0x00		
#define COMM_MAP_VCU_SW_VERSION						0x01		
// == MOTOR CTRL  (Standard 12 BYTE) 
#define COMM_MAP_VCU_VEL_FL_CTRL	                0x10
#define COMM_MAP_VCU_VEL_FR_CTRL	                0x11
#define COMM_MAP_VCU_VEL_R_CTRL	                    0x12
#define COMM_MAP_VCU_ANGLE_FL_CTRL	                0x13
#define COMM_MAP_VCU_ANGLE_FR_CTRL	                0x14
#define COMM_MAP_VCU_ANGLE_R_CTRL	                0x15
// == MOTOR FEEDBACK  (Standard 12 BYTE)
#define COMM_MAP_VCU_VEL_FL_FB	                    0x20
#define COMM_MAP_VCU_VEL_FR_FB	                    0x21
#define COMM_MAP_VCU_VEL_R_FB	                    0x22
#define COMM_MAP_VCU_ANGLE_FL_FB	                0x23
#define COMM_MAP_VCU_ANGLE_FR_FB	                0x24
#define COMM_MAP_VCU_ANGLE_R_FB	                    0x25
// == CHASSIS CTRL  (Standard 8 BYTE)
#define COMM_MAP_VCU_CHASSIS_MODE	                0x30
#define COMM_MAP_VCU_CHASSIS_VX	                    0x31
#define COMM_MAP_VCU_CHASSIS_VY	                    0x32
#define COMM_MAP_VCU_CHASSIS_VW	                    0x33
// == ERROR  (Standard 4 BYTE)
#define COMM_MAP_VCU_ERR_STATE_L	    0xF0
#define COMM_MAP_VCU_ERR_STATE_H	    0xF1

extern int16_t gR1proVcuCtrlMap[VCU_CTRLMAP_LEN];
extern bool gR1proVcuMapUpdated[VCU_CTRLMAP_LEN];
  
#endif 













































