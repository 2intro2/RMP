#ifndef HDAS_NODE_ARM_MAP_H
#define HDAS_NODE_ARM_MAP_H

// arm_feedback
#define pos_fb_joint0_high 0
#define pos_fb_joint0_low 1
#define vel_fb_joint0_high 2
#define vel_fb_joint0_low 3
#define tff_fb_joint0_high 4
#define tff_fb_joint0_low 5

#define pos_fb_joint1_high 6
#define pos_fb_joint1_low 7
#define vel_fb_joint1_high 8
#define vel_fb_joint1_low 9
#define tff_fb_joint1_high 10
#define tff_fb_joint1_low 11

#define pos_fb_joint2_high 12
#define pos_fb_joint2_low 13
#define vel_fb_joint2_high 14
#define vel_fb_joint2_low 15
#define tff_fb_joint2_high 16
#define tff_fb_joint2_low 17

#define pos_fb_joint3_high 18
#define pos_fb_joint3_low 19
#define vel_fb_joint3_high 20
#define vel_fb_joint3_low 21
#define tff_fb_joint3_high 22
#define tff_fb_joint3_low 23

#define pos_fb_joint4_high 24
#define pos_fb_joint4_low 25
#define vel_fb_joint4_high 26
#define vel_fb_joint4_low 27
#define tff_fb_joint4_high 28
#define tff_fb_joint4_low 29

#define pos_fb_joint5_high 30
#define pos_fb_joint5_low 31
#define vel_fb_joint5_high 32
#define vel_fb_joint5_low 33
#define tff_fb_joint5_high 34
#define tff_fb_joint5_low 35

#define pos_fb_joint6_high 36
#define pos_fb_joint6_low 37
#define vel_fb_joint6_high 38
#define vel_fb_joint6_low 39
#define tff_fb_joint6_high 40
#define tff_fb_joint6_low 41

#define pos_fb_gripper_high 36
#define pos_fb_gripper_low 37
#define vel_fb_gripper_high 38
#define vel_fb_gripper_low 39
#define tff_fb_gripper_high 40
#define tff_fb_gripper_low 41

// arm_control
#define pos_ctrl_joint0_high 0
#define pos_ctrl_joint0_low 1
#define vel_ctrl_joint0_high 2
#define vel_ctrl_joint0_low 3
#define kp_ctrl_joint0_high 4
#define kp_ctrl_joint0_low 5
#define kd_ctrl_joint0_high 6
#define kd_ctrl_joint0_low 7
#define tff_ctrl_joint0_high 8
#define tff_ctrl_joint0_low 9

#define pos_ctrl_joint1_high 10
#define pos_ctrl_joint1_low 11
#define vel_ctrl_joint1_high 12
#define vel_ctrl_joint1_low 13
#define kp_ctrl_joint1_high 14
#define kp_ctrl_joint1_low 15
#define kd_ctrl_joint1_high 16
#define kd_ctrl_joint1_low 17
#define tff_ctrl_joint1_high 18
#define tff_ctrl_joint1_low 19

#define pos_ctrl_joint2_high 20
#define pos_ctrl_joint2_low 21
#define vel_ctrl_joint2_high 22
#define vel_ctrl_joint2_low 23
#define kp_ctrl_joint2_high 24
#define kp_ctrl_joint2_low 25
#define kd_ctrl_joint2_high 26
#define kd_ctrl_joint2_low 27
#define tff_ctrl_joint2_high 28
#define tff_ctrl_joint2_low 29

#define pos_ctrl_joint3_high 30
#define pos_ctrl_joint3_low 31
#define vel_ctrl_joint3_high 32
#define vel_ctrl_joint3_low 33
#define kp_ctrl_joint3_high 34
#define kp_ctrl_joint3_low 35
#define kd_ctrl_joint3_high 36
#define kd_ctrl_joint3_low 37
#define tff_ctrl_joint3_high 38
#define tff_ctrl_joint3_low 39


#define pos_ctrl_joint4_high 40
#define pos_ctrl_joint4_low 41
#define vel_ctrl_joint4_high 42
#define vel_ctrl_joint4_low 43
#define kp_ctrl_joint4_high 44
#define kp_ctrl_joint4_low 45
#define kd_ctrl_joint4_high 46
#define kd_ctrl_joint4_low 47
#define tff_ctrl_joint4_high 48
#define tff_ctrl_joint4_low 49


#define pos_ctrl_joint5_high 50
#define pos_ctrl_joint5_low 51
#define vel_ctrl_joint5_high 52
#define vel_ctrl_joint5_low 53
#define kp_ctrl_joint5_high 54
#define kp_ctrl_joint5_low 55
#define kd_ctrl_joint5_high 56
#define kd_ctrl_joint5_low 57
#define tff_ctrl_joint5_high 58
#define tff_ctrl_joint5_low 59

//command
#define arm_command 0

//error
#define arm_error_high 0
#define arm_error_low 1

//arm gripper control
#define gripper_pos_ctrl_high 0
#define gripper_pos_ctrl_low 1
#define gripper_vel_ctrl_high 2
#define gripper_vel_ctrl_low 3
#define gripper_kp_ctrl_high 4
#define gripper_kp_ctrl_low 5
#define gripper_kd_ctrl_high 6
#define gripper_kd_ctrl_low 7
#define gripper_tff_ctrl_high 8
#define gripper_tff_ctrl_low 9


#endif // HDAS_NODE_ARM_MAP_H