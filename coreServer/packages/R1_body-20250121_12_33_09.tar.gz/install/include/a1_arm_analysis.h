//
// Created by gerunze on 24-12-31.
//

#ifndef A1_ARM_ANALYSIS_H
#define A1_ARM_ANALYSIS_H

#include "common.h"
#include "communication_struct.hpp"
#include <iostream>
#include <cmath>
namespace a1_arm_analysis {
    static const float p_kScale = 4700.0f;
    static const float v_kScale = 750.0f;
    static const float kp_kScale = 60.0f;
    static const float kd_kScale = 150.0f;
    static const float tff_kScale = 600.0f;

    static const float pLimit = 6.5f;
    static const float vLimit = 40.0f;
    static const float kpLimit = 500.0f;
    static const float kdLimit = 200.0f;
    static const float tffLimit = 50.0f;

    static const float constraint1 = 45 * M_PI / 180.0;
    static const float constraint2 = 90 * M_PI /180.0;
    static const float constraint3 = 135 * M_PI /180.0;
    static const float constraint4 = 180 * M_PI /180.0;
    static const float radius = 17.5;
    static const float constant = 22.5 * M_PI /180.0;

    static const float bias = 6.24 * M_PI / 180.0;

    inline int16_t combineBytes(uint8_t high_byte, uint8_t low_byte){
        return (static_cast<int16_t>(high_byte) << 8) | low_byte;
    }

    inline void splitInt16(int16_t value, uint8_t &high_byte, uint8_t &low_byte) {
        high_byte = static_cast<uint8_t>((value >> 8) & 0xFF);
        low_byte = static_cast<uint8_t>(value & 0xFF);
    }

    inline double convertInt16toDouble(int16_t value, float scale) {
        double result = static_cast<double>(value) / scale;
        return result;
    }

    inline int16_t convertFloatToInt16(float value, float scale) {
        float scaledValue = value;
        if (scale == p_kScale){
            if (scaledValue > pLimit){
                scaledValue = pLimit;
            }else if (scaledValue < -pLimit){
                scaledValue = -pLimit;
            }
        }else if (scale == v_kScale)
        {
            if (scaledValue > vLimit){
                scaledValue = vLimit;
            }else if (scaledValue < -vLimit){
                scaledValue = -vLimit;
            }
        }else if (scale == kp_kScale)
        {
            if (scaledValue > kpLimit){
                scaledValue = kpLimit;
            }else if (scaledValue <= 0.0f){
                scaledValue = 0.0f;
            }

        }else if (scale == kd_kScale)
        {
            if (scaledValue > kdLimit){
                scaledValue = kdLimit;
            }else if (scaledValue <= 0.0f){
                scaledValue = 0.0f;
            }

        }else if (scale == tff_kScale)
        {
            if (scaledValue > tffLimit){
                scaledValue = tffLimit;
            }else if (scaledValue < -tffLimit){
                scaledValue = -tffLimit;
            }
        }else {
            std::cout << "THIS IS UNKOWN SCALE VALUE!!!" << std::endl;
        }
        scaledValue = scaledValue * scale;

        return static_cast<int16_t>(scaledValue);
    }



    inline void arm_encode_impl(std::vector<uint8_t>& data, const arm_control_command& arm_control_command){
        uint8_t high_byte = 0x00;
        uint8_t low_byte = 0x00;
        // p_des
        splitInt16(convertFloatToInt16(arm_control_command.p_des[0], p_kScale), high_byte, low_byte);
        data[0] = high_byte;
        data[1] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.v_des[0], v_kScale), high_byte, low_byte);
        data[2] = high_byte;
        data[3] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.kp[0], kp_kScale), high_byte, low_byte);
        data[4] = high_byte;
        data[5] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.kd[0], kd_kScale), high_byte, low_byte);
        data[6] = high_byte;
        data[7] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.t_ff[0], tff_kScale), high_byte, low_byte);
        data[8] = high_byte;
        data[9] = low_byte;

        splitInt16(convertFloatToInt16(arm_control_command.p_des[1], p_kScale), high_byte, low_byte);
        data[10] = high_byte;
        data[11] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.v_des[1], v_kScale), high_byte, low_byte);
        data[12] = high_byte;
        data[13] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.kp[1], kp_kScale), high_byte, low_byte);
        data[14] = high_byte;
        data[15] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.kd[1], kd_kScale), high_byte, low_byte);
        data[16] = high_byte;
        data[17] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.t_ff[1], tff_kScale), high_byte, low_byte);
        data[18] = high_byte;
        data[19] = low_byte;

        splitInt16(convertFloatToInt16(arm_control_command.p_des[2], p_kScale), high_byte, low_byte);
        data[20] = high_byte;
        data[21] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.v_des[2], v_kScale), high_byte, low_byte);
        data[22] = high_byte;
        data[23] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.kp[2], kp_kScale), high_byte, low_byte);
        data[24] = high_byte;
        data[25] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.kd[2], kd_kScale), high_byte, low_byte);
        data[26] = high_byte;
        data[27] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.t_ff[2], tff_kScale), high_byte, low_byte);
        data[28] = high_byte;
        data[29] = low_byte;

        splitInt16(convertFloatToInt16(arm_control_command.p_des[3], p_kScale), high_byte, low_byte);
        data[30] = high_byte;
        data[31] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.v_des[3], v_kScale), high_byte, low_byte);
        data[32] = high_byte;
        data[33] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.kp[3], kp_kScale), high_byte, low_byte);
        data[34] = high_byte;
        data[35] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.kd[3], kd_kScale), high_byte, low_byte);
        data[36] = high_byte;
        data[37] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.t_ff[3], tff_kScale), high_byte, low_byte);
        data[38] = high_byte;
        data[39] = low_byte;

        splitInt16(convertFloatToInt16(arm_control_command.p_des[4], p_kScale), high_byte, low_byte);
        data[40] = high_byte;
        data[41] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.v_des[4], v_kScale), high_byte, low_byte);
        data[42] = high_byte;
        data[43] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.kp[4], kp_kScale), high_byte, low_byte);
        data[44] = high_byte;
        data[45] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.kd[4], kd_kScale), high_byte, low_byte);
        data[46] = high_byte;
        data[47] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.t_ff[4], tff_kScale), high_byte, low_byte);
        data[48] = high_byte;
        data[49] = low_byte;

        splitInt16(convertFloatToInt16(arm_control_command.p_des[5], p_kScale), high_byte, low_byte);
        data[50] = high_byte;
        data[51] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.v_des[5], v_kScale), high_byte, low_byte);
        data[52] = high_byte;
        data[53] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.kp[5], kp_kScale), high_byte, low_byte);
        data[54] = high_byte;
        data[55] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.kd[5], kd_kScale), high_byte, low_byte);
        data[56] = high_byte;
        data[57] = low_byte;
        splitInt16(convertFloatToInt16(arm_control_command.t_ff[5], tff_kScale), high_byte, low_byte);
        data[58] = high_byte;
        data[59] = low_byte;
    }

    inline void gripper_encode_impl(std::vector<uint8_t>& data, const gripper_control_command& gripper_control_command) {
        uint8_t high_byte = 0x00;
        uint8_t low_byte = 0x00;
        splitInt16(convertFloatToInt16(gripper_control_command.p_des[0], p_kScale), high_byte, low_byte);
        data[0] = high_byte;
        data[1] = low_byte;
        splitInt16(convertFloatToInt16(gripper_control_command.v_des[0], v_kScale), high_byte, low_byte);
        data[2] = high_byte;
        data[3] = low_byte;
        splitInt16(convertFloatToInt16(gripper_control_command.kp[0], kp_kScale), high_byte, low_byte);
        data[4] = high_byte;
        data[5] = low_byte;
        splitInt16(convertFloatToInt16(gripper_control_command.kd[0], kd_kScale), high_byte, low_byte);
        data[6] = high_byte;
        data[7] = low_byte;
        splitInt16(convertFloatToInt16(gripper_control_command.t_ff[0], tff_kScale), high_byte, low_byte);
        data[8] = high_byte;
        data[9] = low_byte;

    }

    inline CAN_frame encode_arm(const arm_control_command& arm_control_command, const std::string& name) {
       std::vector<uint8_t> data(60,0x00);
       arm_encode_impl(data, arm_control_command);
        CAN_frame canFrame;
        if (name == "LEFT_ARM"){
            canFrame.can_id = 0x50;
        }else if (name == "RIGHT_ARM")
        {
            canFrame.can_id = 0x60;
        }
        canFrame.data = data;
        canFrame.len = data.size();
        return canFrame;
    }

    inline CAN_frame encode_gripper(const gripper_control_command& gripper_control_command, const std::string& name) {
        std::vector<uint8_t> data(10,0x00);
        gripper_encode_impl(data, gripper_control_command);
        CAN_frame canFrame;
        if (name == "LEFT_Gripper") {
            canFrame.can_id = 0x51;
        }else if (name == "RIGHT_Gripper") {
            canFrame.can_id = 0x61;
        }
        canFrame.data = data;
        canFrame.len = data.size();
        return canFrame;
    }



    inline std::pair<serial_feedback_arm, serial_feedback_gripper> arm_decode_impl(const std::shared_ptr<CAN_frame>& canFrame){
        std::vector<uint8_t> data = canFrame -> data;
        serial_feedback_arm serial_feedback_arm;
        serial_feedback_arm.position.resize(7);
        serial_feedback_arm.velocity.resize(7);
        serial_feedback_arm.torque.resize(7);
        serial_feedback_arm.position[0] = convertInt16toDouble(combineBytes(data[pos_fb_joint0_high], data[pos_fb_joint0_low]), p_kScale);
        serial_feedback_arm.position[1] = convertInt16toDouble(combineBytes(data[pos_fb_joint1_high], data[pos_fb_joint1_low]), p_kScale);
        serial_feedback_arm.position[2] = convertInt16toDouble(combineBytes(data[pos_fb_joint2_high], data[pos_fb_joint2_low]), p_kScale);
        serial_feedback_arm.position[3] = convertInt16toDouble(combineBytes(data[pos_fb_joint3_high], data[pos_fb_joint3_low]), p_kScale);
        serial_feedback_arm.position[4] = convertInt16toDouble(combineBytes(data[pos_fb_joint4_high], data[pos_fb_joint4_low]), p_kScale);
        serial_feedback_arm.position[5] = convertInt16toDouble(combineBytes(data[pos_fb_joint5_high], data[pos_fb_joint5_low]), p_kScale);
        serial_feedback_arm.position[6] = convertInt16toDouble(combineBytes(data[pos_fb_gripper_high], data[pos_fb_gripper_low]), p_kScale);
        serial_feedback_arm.velocity[0] = convertInt16toDouble(combineBytes(data[vel_fb_joint0_high], data[vel_fb_joint0_low]), v_kScale);
        serial_feedback_arm.velocity[1] = convertInt16toDouble(combineBytes(data[vel_fb_joint1_high], data[vel_fb_joint1_low]), v_kScale);
        serial_feedback_arm.velocity[2] = convertInt16toDouble(combineBytes(data[vel_fb_joint2_high], data[vel_fb_joint2_low]), v_kScale);
        serial_feedback_arm.velocity[3] = convertInt16toDouble(combineBytes(data[vel_fb_joint3_high], data[vel_fb_joint3_low]), v_kScale);
        serial_feedback_arm.velocity[4] = convertInt16toDouble(combineBytes(data[vel_fb_joint4_high], data[vel_fb_joint4_low]), v_kScale);
        serial_feedback_arm.velocity[5] = convertInt16toDouble(combineBytes(data[vel_fb_joint5_high], data[vel_fb_joint5_low]), v_kScale);
        serial_feedback_arm.velocity[6] = convertInt16toDouble(combineBytes(data[vel_fb_gripper_high], data[vel_fb_gripper_low]), v_kScale);
        serial_feedback_arm.torque[0] = convertInt16toDouble(combineBytes(data[tff_fb_joint0_high], data[tff_fb_joint0_low]), tff_kScale);
        serial_feedback_arm.torque[1] = convertInt16toDouble(combineBytes(data[tff_fb_joint1_high], data[tff_fb_joint1_low]), tff_kScale);
        serial_feedback_arm.torque[2] = convertInt16toDouble(combineBytes(data[tff_fb_joint2_high], data[tff_fb_joint2_low]), tff_kScale);
        serial_feedback_arm.torque[3] = convertInt16toDouble(combineBytes(data[tff_fb_joint3_high], data[tff_fb_joint3_low]), tff_kScale);
        serial_feedback_arm.torque[4] = convertInt16toDouble(combineBytes(data[tff_fb_joint4_high], data[tff_fb_joint4_low]), tff_kScale);
        serial_feedback_arm.torque[5] = convertInt16toDouble(combineBytes(data[tff_fb_joint5_high], data[tff_fb_joint5_low]), tff_kScale);
        serial_feedback_arm.torque[6] = convertInt16toDouble(combineBytes(data[tff_fb_gripper_high], data[tff_fb_gripper_low]), v_kScale);

        // std::cout << "shit end impl" << std::endl;

        serial_feedback_gripper serial_feedback_gripper;
        serial_feedback_gripper.position = convertInt16toDouble(combineBytes(data[pos_fb_gripper_high], data[pos_fb_gripper_low]), p_kScale);
        serial_feedback_gripper.position = convertInt16toDouble(combineBytes(data[pos_fb_gripper_high], data[pos_fb_gripper_low]), p_kScale);
        auto gripper_stroke =0.0;
        // feedback.position[6] = std::abs(feedback.position[6]);
        if (-0.1 < (-serial_feedback_gripper.position+bias) && (-serial_feedback_gripper.position+bias) < constraint1){
            gripper_stroke = radius * std::sin(constant) - 17.5 * std::sin(constant - (-serial_feedback_gripper.position+bias));
            gripper_stroke = gripper_stroke * 2;
        }else if(constraint1 < (-serial_feedback_gripper.position+bias) && (-serial_feedback_gripper.position+bias)< constraint2){
            gripper_stroke = 3 * radius * std::sin(constant) - 17.5 * std::sin(constant - ((-serial_feedback_gripper.position+bias) - 0.78539816));
            gripper_stroke = gripper_stroke * 2;
        }else if(constraint2 < (-serial_feedback_gripper.position+bias) && (-serial_feedback_gripper.position+bias)< constraint3){
            gripper_stroke = 5 * radius * std::sin(constant) - 17.5 * std::sin(constant - ((-serial_feedback_gripper.position+bias) - 1.57079632));
            gripper_stroke = gripper_stroke * 2;
        }else if(constraint3 < (-serial_feedback_gripper.position+bias) && (-serial_feedback_gripper.position+bias)< constraint4){
            gripper_stroke = 7 * radius * std::sin(constant) - 17.5 * std::sin(constant - ((-serial_feedback_gripper.position+bias)- 2.35619449));
            gripper_stroke = gripper_stroke * 2;
        }else{
            std::cerr << "gripper_position is out of limit" << std::endl;
        }
        serial_feedback_gripper.position = gripper_stroke;
        serial_feedback_gripper.velocity = convertInt16toDouble(combineBytes(data[vel_fb_gripper_high], data[vel_fb_gripper_low]), v_kScale);
        serial_feedback_gripper.torque = convertInt16toDouble(combineBytes(data[tff_fb_gripper_high], data[tff_fb_gripper_low]), v_kScale);

        return {serial_feedback_arm, serial_feedback_gripper};
    }
};
#endif //A1_ARM_ANALYSIS_H
