#ifndef A2_ARM_ANALYSIS_H
#define A2_ARM_ANALYSIS_H

#include "common.h"
#include "communication_struct.hpp"
#include <iostream>
#include <bitset>
#include <cmath>

namespace a2_arm_analysis {
    static const float fb_p_kScale = 4700.0f;
    static const float fb_v_kScale = 750.0f;
    static const float fb_tff_kScale = 600.0f;

    static const float fb_pLimit = 6.5f;
    static const float fb_vLimit = 40.0f;
    static const float fb_tffLimit = 50.0f;


    static const float ctrl_p_kScale = 4777.0f;
    static const float ctrl_v_kScale = 250.0f;
    static const float ctrl_kp_kScale = 1.0f;
    static const float ctrl_kd_kScale = 1.0f;
    static const float ctrl_tff_kScale = 20.0f;

    static const float ctrl_p_Limit = 6.28f;
    static const float ctrl_v_Limit = 8.0f;
    static const float ctrl_kp_Limit = 4095.0f;
    static const float ctrl_kd_Limit = 4095.0f;
    static const float ctrl_tff_Limit = 100.0f;


    inline int16_t combineBytes(uint8_t high_byte, uint8_t low_byte){
        return (static_cast<int16_t>(high_byte) << 8) | low_byte;
    }

    inline void splitInt16(int16_t value, uint8_t &high_byte, uint8_t &low_byte) {
        high_byte = static_cast<uint8_t>((value >> 8) & 0xFF);
        low_byte = static_cast<uint8_t>(value & 0xFF);
    }

    inline double convertInt16toDouble(int16_t value, float scale) {
        double result = static_cast<double>(value) / scale;
        return result;
    }

    inline int16_t convertFloatToInt16P(float value, float scale) {
        float scaledValue = value;
        if (scale == ctrl_p_kScale){
            if (scaledValue > ctrl_p_Limit){
                scaledValue = ctrl_p_Limit;
            }
            else if (scaledValue < -ctrl_p_Limit) {
                scaledValue = -ctrl_p_Limit;
            }
        }else {
            std::cout << "THIS IS UNKOWN SCALE VALUE!!!" << std::endl;
        }
        scaledValue = scaledValue * scale;
        int16_t result = static_cast<int16_t>(scaledValue);
        return result;
    }

    inline int16_t convertFloatToInt16VTFF(float value, float scale) {
        bool is_negative = false;
        if(value < 0) is_negative = true;
        value = std::abs(value);
        float scaledValue = value;
        if (scale == ctrl_p_kScale){
            if (scaledValue > ctrl_p_Limit){
                scaledValue = ctrl_p_Limit;
            }
        }else if (scale == ctrl_v_kScale)
        {
            if (scaledValue > ctrl_v_Limit){
                scaledValue = ctrl_v_Limit;
            }
        }else if (scale == ctrl_tff_kScale)
        {
            if (scaledValue > ctrl_tff_Limit){
                scaledValue = ctrl_tff_Limit;
            }
        }else {
            std::cout << "THIS IS UNKOWN SCALE VALUE!!!" << std::endl;
        }
        scaledValue = scaledValue * scale;
        int16_t result = static_cast<int16_t>(scaledValue);
        if (is_negative == true) result |= 0x0800;
        return result;
    }

    inline int16_t convertFloatToInt16_KPKD(float value, float scale) {
        float scaledValue = value;
        if (scale == ctrl_kp_kScale){
            if (scaledValue > ctrl_kp_Limit){
                scaledValue = ctrl_kp_Limit;
            }else if (scaledValue < 0){
                scaledValue = 0;
            }
        }else if (scale == ctrl_kd_kScale) {
            if (scaledValue > ctrl_kd_Limit){
                scaledValue = ctrl_kd_Limit;
            }else if (scaledValue < 0){
                scaledValue = 0;
            }
        }
        scaledValue = scaledValue * scale;
        int16_t result = static_cast<int16_t>(scaledValue);
        return result;
    }


    inline void arm_encode_impl(std::vector<uint8_t>& data, const arm_control_command& arm_control_command){
        uint8_t high_byte = 0x00;
        uint8_t low_byte = 0x00;
        for(int i = 0; i < 7; i++) {
            splitInt16(convertFloatToInt16P(arm_control_command.p_des[i], ctrl_p_kScale), high_byte, low_byte);
            data[i*8+0] = high_byte;
            data[i*8+1] = low_byte;
            int16_t v_result = convertFloatToInt16VTFF(arm_control_command.v_des[i], ctrl_v_kScale);
            int16_t kp_result = convertFloatToInt16_KPKD(arm_control_command.kp[i], ctrl_kp_kScale);
            int16_t kd_result = convertFloatToInt16_KPKD(arm_control_command.kd[i], ctrl_kd_kScale);
            int16_t tff_result = convertFloatToInt16VTFF(arm_control_command.t_ff[i], ctrl_tff_kScale);
            data[i*8+2] = (v_result >> 4) & 0xFF;
            data[i*8+3] = ((v_result & 0x0F) << 4) | ((kp_result >> 8) & 0x0F);
            data[i*8+4] = (kp_result & 0xFF);
            data[i*8+5] = (kd_result >> 4) & 0xFF;
            data[i*8+6] = ((kd_result & 0x0F) << 4) | ((tff_result >> 8) & 0x0F);
            data[i*8+7] = (tff_result & 0xFF);
        }
    }

    inline void gripper_encode_impl(std::vector<uint8_t>& data, const gripper_control_command& gripper_control_command) {
        // uint8_t high_byte = 0x00;
        // uint8_t low_byte = 0x00;
        // splitInt16(convertFloatToInt16(gripper_control_command.p_des[0], p_kScale), high_byte, low_byte);
        // data[0] = high_byte;
        // data[1] = low_byte;
        // splitInt16(convertFloatToInt16(gripper_control_command.v_des[0], v_kScale), high_byte, low_byte);
        // data[2] = high_byte;
        // data[3] = low_byte;
        // splitInt16(convertFloatToInt16(gripper_control_command.kp[0], kp_kScale), high_byte, low_byte);
        // data[4] = high_byte;
        // data[5] = low_byte;
        // splitInt16(convertFloatToInt16(gripper_control_command.kd[0], kd_kScale), high_byte, low_byte);
        // data[6] = high_byte;
        // data[7] = low_byte;
        // splitInt16(convertFloatToInt16(gripper_control_command.t_ff[0], tff_kScale), high_byte, low_byte);
        // data[8] = high_byte;
        // data[9] = low_byte;
    }

    inline CAN_frame encode_arm(const arm_control_command& arm_control_command, const std::string& name) {
       std::vector<uint8_t> data(56,0x00);
       arm_encode_impl(data, arm_control_command);
        CAN_frame canFrame;
        if (name == "LEFT_ARM"){
            canFrame.can_id = 0x50;
        }else if (name == "RIGHT_ARM")
        {
            canFrame.can_id = 0x60;
        }
        canFrame.data = data;
        canFrame.len = data.size();
        return canFrame;
    }

    inline CAN_frame encode_gripper(const gripper_control_command& gripper_control_command, const std::string& name) {
        std::vector<uint8_t> data(10,0x00);
        gripper_encode_impl(data, gripper_control_command);
        CAN_frame canFrame;
        if (name == "LEFT_Gripper") {
            canFrame.can_id = 0x51;
        }else if (name == "RIGHT_Gripper") {
            canFrame.can_id = 0x61;
        }
        canFrame.data = data;
        canFrame.len = data.size();
        return canFrame;
    }
    


    inline std::pair<serial_feedback_arm, serial_feedback_gripper> arm_decode_impl(const std::shared_ptr<CAN_frame>& canFrame){
        std::vector<uint8_t> data = canFrame -> data;
        serial_feedback_arm serial_feedback_arm;
        serial_feedback_arm.position.resize(7);
        serial_feedback_arm.velocity.resize(7);
        serial_feedback_arm.torque.resize(7);
        serial_feedback_arm.position[0] = convertInt16toDouble(combineBytes(data[pos_fb_joint0_high], data[pos_fb_joint0_low]), fb_p_kScale);
        serial_feedback_arm.position[1] = convertInt16toDouble(combineBytes(data[pos_fb_joint1_high], data[pos_fb_joint1_low]), fb_p_kScale);
        serial_feedback_arm.position[2] = convertInt16toDouble(combineBytes(data[pos_fb_joint2_high], data[pos_fb_joint2_low]), fb_p_kScale);
        serial_feedback_arm.position[3] = convertInt16toDouble(combineBytes(data[pos_fb_joint3_high], data[pos_fb_joint3_low]), fb_p_kScale);
        serial_feedback_arm.position[4] = convertInt16toDouble(combineBytes(data[pos_fb_joint4_high], data[pos_fb_joint4_low]), fb_p_kScale);
        serial_feedback_arm.position[5] = convertInt16toDouble(combineBytes(data[pos_fb_joint5_high], data[pos_fb_joint5_low]), fb_p_kScale);
        serial_feedback_arm.position[6] = convertInt16toDouble(combineBytes(data[pos_fb_joint6_high], data[pos_fb_joint6_low]), fb_p_kScale);
        serial_feedback_arm.velocity[0] = convertInt16toDouble(combineBytes(data[vel_fb_joint0_high], data[vel_fb_joint0_low]), fb_v_kScale);
        serial_feedback_arm.velocity[1] = convertInt16toDouble(combineBytes(data[vel_fb_joint1_high], data[vel_fb_joint1_low]), fb_v_kScale);
        serial_feedback_arm.velocity[2] = convertInt16toDouble(combineBytes(data[vel_fb_joint2_high], data[vel_fb_joint2_low]), fb_v_kScale);
        serial_feedback_arm.velocity[3] = convertInt16toDouble(combineBytes(data[vel_fb_joint3_high], data[vel_fb_joint3_low]), fb_v_kScale);
        serial_feedback_arm.velocity[4] = convertInt16toDouble(combineBytes(data[vel_fb_joint4_high], data[vel_fb_joint4_low]), fb_v_kScale);
        serial_feedback_arm.velocity[5] = convertInt16toDouble(combineBytes(data[vel_fb_joint5_high], data[vel_fb_joint5_low]), fb_v_kScale);
        serial_feedback_arm.velocity[6] = convertInt16toDouble(combineBytes(data[vel_fb_joint6_high], data[vel_fb_joint6_low]), fb_v_kScale);
        serial_feedback_arm.torque[0] = convertInt16toDouble(combineBytes(data[tff_fb_joint0_high], data[tff_fb_joint0_low]), fb_tff_kScale);
        serial_feedback_arm.torque[1] = convertInt16toDouble(combineBytes(data[tff_fb_joint1_high], data[tff_fb_joint1_low]), fb_tff_kScale);
        serial_feedback_arm.torque[2] = convertInt16toDouble(combineBytes(data[tff_fb_joint2_high], data[tff_fb_joint2_low]), fb_tff_kScale);
        serial_feedback_arm.torque[3] = convertInt16toDouble(combineBytes(data[tff_fb_joint3_high], data[tff_fb_joint3_low]), fb_tff_kScale);
        serial_feedback_arm.torque[4] = convertInt16toDouble(combineBytes(data[tff_fb_joint4_high], data[tff_fb_joint4_low]), fb_tff_kScale);
        serial_feedback_arm.torque[5] = convertInt16toDouble(combineBytes(data[tff_fb_joint5_high], data[tff_fb_joint5_low]), fb_tff_kScale);
        serial_feedback_arm.torque[6] = convertInt16toDouble(combineBytes(data[tff_fb_joint6_high], data[tff_fb_joint6_low]), fb_tff_kScale);

        serial_feedback_gripper serial_feedback_gripper;


        return {serial_feedback_arm, serial_feedback_gripper};
    }
};

#endif //A2_ARM_ANALYSIS_H
 