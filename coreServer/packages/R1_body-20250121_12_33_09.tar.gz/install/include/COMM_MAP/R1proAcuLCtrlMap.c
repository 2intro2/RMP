#include "R1proAcuLCtrlMap.h"

int16_t gR1proAcuLCtrlMap[ACUL_CTRLMAP_LEN];
bool gR1proAcuLMapUpdated[ACUL_CTRLMAP_LEN] = {false};	
