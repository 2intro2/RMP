#ifndef _R1PROTCUCTRLMAP_H_
#define _R1PROTCUCTRLMAP_H_

#include <stdint.h>
#include <stdbool.h>

#define TCU_CTRLMAP_LEN						    256					

#define COMM_MAP_TCU_FW_VERSION					0x00	
#define COMM_MAP_TCU_SW_VERSION					0x01	

// == W FEEDBACK  (Standard 20 BYTE) 
#define COMM_MAP_TCU_W1_FB						    0x10	  //5 byte
#define COMM_MAP_TCU_W2_FB						    0x15	  
#define COMM_MAP_TCU_W3_FB						    0x1A	  
#define COMM_MAP_TCU_W4_FB						    0x1F	  

// == W SERVO CTRL  (Standard 16 BYTE) 
#define COMM_MAP_TCU_W1_SERVO_POS					0x30		
#define COMM_MAP_TCU_W1_SERVO_VEL_LIMIT			    0x31	
#define COMM_MAP_TCU_W2_SERVO_POS					0x33		
#define COMM_MAP_TCU_W2_SERVO_VEL_LIMIT			    0x34
#define COMM_MAP_TCU_W3_SERVO_POS					0x35		
#define COMM_MAP_TCU_W3_SERVO_VEL_LIMIT			    0x36
#define COMM_MAP_TCU_W4_SERVO_POS					0x37		
#define COMM_MAP_TCU_W4_SERVO_VEL_LIMIT			    0x38

// == IMU  (Standard 18 BYTE) 
#define COMM_MAP_TCU_IMU_ROLL					    0x40	
#define COMM_MAP_TCU_IMU_PITCH  				    0x41	
#define COMM_MAP_TCU_IMU_YAW   					    0x42
#define COMM_MAP_TCU_IMU_ACC_X					    0x43	
#define COMM_MAP_TCU_IMU_ACC_Y					    0x44	
#define COMM_MAP_TCU_IMU_ACC_Z					    0x45	
#define COMM_MAP_TCU_IMU_GROY_X					    0x46	
#define COMM_MAP_TCU_IMU_GROY_Y					    0x47	
#define COMM_MAP_TCU_IMU_GROY_Z					    0x48

// == ERROR  (Standard 4 BYTE) 
#define COMM_MAP_TCU_ERR_STATE_L	                0xF0
#define COMM_MAP_TCU_ERR_STATE_H	                0xF1

extern int16_t gR1proVcuCtrlMap[TCU_CTRLMAP_LEN];
extern bool gR1proVcuMapUpdated[TCU_CTRLMAP_LEN];

#endif 













































