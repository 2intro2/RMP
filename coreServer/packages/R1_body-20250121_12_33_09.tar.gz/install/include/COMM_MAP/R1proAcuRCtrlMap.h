#ifndef _R1PROACURCTRLMAP_H_
#define _R1PROACURCTRLMAP_H_

#include <stdint.h>
#include <stdbool.h>

#define ACUR_CTRLMAP_LEN						        256					

#define COMM_MAP_ACUR_FW_VERSION						0x00		
#define COMM_MAP_ACUR_SW_VERSION						0x01		
// == JOINT FEEDBACK  (Standard 30 BYTE) 
#define COMM_MAP_ACUR_J1_FB						        0x10	  //5 byte
#define COMM_MAP_ACUR_J2_FB						        0x15	  
#define COMM_MAP_ACUR_J3_FB						        0x1A	  
#define COMM_MAP_ACUR_J4_FB						        0x1F	  
#define COMM_MAP_ACUR_J5_FB						        0x24	  
#define COMM_MAP_ACUR_J6_FB						        0x29	  

// == JOINT CTRL  (Standard 48 BYTE) 
#define COMM_MAP_ACUR_J1_MIT_CTRL					    0x30	//8 byte	
#define COMM_MAP_ACUR_J2_MIT_CTRL					    0x38
#define COMM_MAP_ACUR_J3_MIT_CTRL					    0x40		
#define COMM_MAP_ACUR_J4_MIT_CTRL					    0x48
#define COMM_MAP_ACUR_J5_MIT_CTRL					    0x50		
#define COMM_MAP_ACUR_J6_MIT_CTRL					    0x58		

// == gripper FEEDBACK  (Standard 2 BYTE) 
#define COMM_MAP_ACUR_J6_FB						        0x60	
// == gripper CTRL  (Standard 2 BYTE) 
#define COMM_MAP_ACUR_J6_MIT_CTRL					    0x70	


// == ERROR
#define COMM_MAP_ACUR_ERR_STATE_L	                    0xF0
#define COMM_MAP_ACUR_ERR_STATE_H	                    0xF1

extern int16_t gR1proACURCtrlMap[ACUR_CTRLMAP_LEN];
extern bool gR1proACURMapUpdated[ACUR_CTRLMAP_LEN];

#endif 













































